<?php

return [
    'buttons' => [
        'send' => 'Send',
        'save' => 'Save',
        'select_image' => 'Select an image',
        'download' => 'Download',
        'cancel' => 'Cancel',
        'error' => 'Error',
        'select' => 'Select'
    ],
    'uploaded_at' => "Uploaded on :date at :time"
];
