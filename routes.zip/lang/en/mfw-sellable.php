<?php

return [
    'vat' => [
       'label' => 'VAT',
        'percent' => 'VAT rate in percent',
        'rate' => 'Rate',
        'new' => 'New VAT rate',
        'is_this_default' => "Is this the default vat rate ?",
        'default' => 'Default'
    ],
    'price' => 'Price',
    'duration' => 'Duration',
];
