<?php

return [
    'no_data_in_db' => "Aucun enregistrement dans la base de données",
    'bad_access' => [
        'must_authenticate' => "Vous devez vous authentifier",
        'is_not_owner' => 'Vous ne pouvez pas accéder à ce contenu.',
        'role' => "Vous n'avez pas le niveau d'accès nécessaire pour effectuer cette action.",
        'mail_not_send' => "L'e-mail n'a pas été envoyé.",
    ],
    'action_got_wrong' => "Cette action n'a pas abouti."
];
