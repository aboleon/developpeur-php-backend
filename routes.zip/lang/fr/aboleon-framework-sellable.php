<?php

return [
    'vat' => [
       'label' => 'TVA',
        'percent' => 'Taux de TVA en pourcentage',
        'rate' => 'Taux',
        'new' => 'Nouveau taux de TVA',
        'is_this_default' => "Est-ce le taux par défaut ?",
        'default' => 'Par défaut',
        'is_used' => "Ce taux de TVA est utilisé."
    ],
    'label' => 'Articles à la vente',
    'price' => 'Prix',
    'sold_per' => 'Vendu par',
    'duration' => 'Durée',
];
