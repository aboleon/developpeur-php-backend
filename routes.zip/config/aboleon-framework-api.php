<?php

return [
    'google' => [
        'places' => '',
        'recaptcha' => [
            'active' => false,
            'site_key' => '',
            'site_secret' => '',
        ]
    ]
];