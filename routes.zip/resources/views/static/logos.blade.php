<div class="container text-center">
    <div class="d-flex justify-content-between align-items-center" id="logos">
        <img loading="lazy" src="https://upload.wikimedia.org/wikipedia/commons/3/36/Logo.min.svg" height="40"/>

        <img loading="lazy" src="https://www.php.net/images/logos/php-logo.svg" height="40"/>

        <img loading="lazy" src="https://upload.wikimedia.org/wikipedia/commons/c/ca/MariaDB_colour_logo.svg"
             height="40"/>

        <img loading="lazy" src="https://upload.wikimedia.org/wikipedia/fr/6/62/MySQL.svg" height="50"/>

        <img loading="lazy" src="https://upload.wikimedia.org/wikipedia/commons/6/6a/JavaScript-logo.png"
             height="50"/>

        <img loading="lazy" src="https://upload.wikimedia.org/wikipedia/fr/b/b3/Jquery-logo.png" height="30"/>

        <img loading="lazy" src="https://raw.githubusercontent.com/livewire/livewire/main/art/readme_logo.png"
             height="50"/>
    </div>
</div>
