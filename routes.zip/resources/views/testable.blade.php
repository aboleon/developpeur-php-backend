<x-aboleon-inputable::input name="hello" label="input"/>
<x-test-component/>
