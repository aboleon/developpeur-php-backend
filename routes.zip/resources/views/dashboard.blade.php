<x-backend-layout>
    <x-slot name="header">
        <h2>
            {{ __('aboleon-framework.nav.dashboard') }}
        </h2>
    </x-slot>

    <div class="py-12">
        <div class="shadow p-4 bg-body-tertiary rounded">
            <div class="bg-white overflow-hidden shadow-xl sm:rounded-lg">
            </div>
        </div>
    </div>
</x-backend-layout>
