<x-front-layout>
    <div class="container">
        <section id="presentation">
            <div class="row align-items-center">
                <div class="col-sm-7">
                    <h1 class="name" style="font-weight: 200">
                        <span style="font-weight: 600">Andrian</span>
                        Mihailov
                    </h1>
                    <span class="email">andrian@developpeur-php-backend.fr</span>
                </div>
                <div class="col-sm-5">
                    <span class="job-title">Developpeur Full Stack PHP</span>
                </div>
            </div>
            <h2 class="lead">Développement et conception d'applications web pour startups et grandes entreprises
            </h2>

            <div class="aboleon-framework-line-separator my-4"></div>

            @include('static.logos')

            <div class="aboleon-framework-line-separator my-4"></div>


            @include('static.hello')
        </section>
        @include('static.stack')
        @include('static.parcours')
        @include('static.projects')


    </div>


    <br><br>


    <footer class="container mb-5">
        <span style="font-size: 16px;">Code & Design : Andrian Mihailov &copy; {{ date('Y') }}</span>
    </footer>


</x-front-layout>
