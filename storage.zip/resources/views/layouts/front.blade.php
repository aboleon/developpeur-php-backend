<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <meta name="ajax-route" content="{{ route("ajax") }}">

    <title>{{ config('app.name', 'Laravel') }}</title>
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@200;300;400;600;700&display=swap" rel="stylesheet">

    <!-- Styles -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
          integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css">

    {!! csscrush_tag(public_path('css/front.css')) !!}

    @stack('css')


</head>
<body>

<nav class="navbar navbar-expand-lg fixed-top">
    <div class="container">
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav"
                aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <i class="bi bi-list"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#presentation">Présentation</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#stack">Stack</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#parcours">Parcours</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#projets">Projets</a>
                </li>
            </ul>
        </div>
    </div>
</nav>

<main>
    @if (isset($slot))
        {{ $slot }}
    @else
        @yield('slot')
    @endif
</main>

@stack('modals')


<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.7.1/dist/jquery.min.js"></script>
<script src="{!! asset('vendor/aboleon/framework/js/common.js') !!}"></script>
@stack('callbacks')
@stack('js')
<script>
    $(document).ready(function () {
        const offset = 100;

        $('.nav-link').on('click', function (e) {
            e.preventDefault();

            let targetId = $(this).attr('href'),
                targetElement = $(targetId),
                targetPosition = targetElement.offset().top - offset;

            $('.nav-link').removeClass('active');
            $(this).addClass('active');
            $('.navbar-collapse').collapse('hide');

            $('html, body').animate({
                scrollTop: targetPosition
            }, 700);
        });
        function updateActiveLink() {
            let currentSection = null;

            $('section').each(function() {
                const sectionTop = $(this).offset().top - offset - 10;
                const sectionBottom = sectionTop + $(this).outerHeight();

                if ($(window).scrollTop() >= sectionTop && $(window).scrollTop() < sectionBottom) {
                    currentSection = $(this).attr('id');
                }
            });

            if (currentSection) {
                $('.nav-link').removeClass('active');
                $(`.nav-link[href="#${currentSection}"]`).addClass('active');
            }
        }

        // Listen for scroll events
        $(window).on('scroll', updateActiveLink);

        // Initial call to set the active link on page load
        updateActiveLink();

    });
</script>
</body>
</html>
