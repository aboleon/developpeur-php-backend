<?php

namespace App\Http\Controllers;

class TestableController extends Controller
{

    public function index()
    {

        return view('testable');


    }
}

