<?php

return [
    'dev' => [
        'label' => 'Développeur',
    ],
    'default' => [
        'label' => 'Invité',
    ],
    'super-admin' => [
        'label' => 'Super-admin',
    ],
    'sales' => [
        'label' => 'Commercial'
    ]
];
